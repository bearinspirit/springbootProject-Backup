$(document).ready(function() {
	$(".menu").click(function () {
	    $(".menu").removeClass("active");
	    $(this).addClass("active");   
	});
});