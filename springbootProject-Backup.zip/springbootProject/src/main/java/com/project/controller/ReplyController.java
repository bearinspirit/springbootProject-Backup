package com.project.controller;

import java.sql.Date;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Enquiry;
import com.project.model.Reply;
import com.project.repository.EnquiryRepository;
import com.project.repository.ReplyRepository;
import com.project.service.EnquiryService;
import com.project.service.ReplyService;

@Controller
public class ReplyController {
	@Autowired
	private ReplyRepository replyrepository;
	
	@Autowired
	private ReplyService replyservice;
	
	public String addReply(@RequestParam("email") String email, @RequestParam("subject") String subject, 
			@RequestParam("admin_reply") String admin_reply, Date date_time, @RequestParam("enquiry_id") Long enquiry_id) {
		
		replyservice.addReply(email, subject, admin_reply, date_time, enquiry_id);
		return "/inbox";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}
	
	public String finalString = null;

	@PostMapping(value="/inbox")
	public String addAReply(@ModelAttribute @Valid Reply newReply, BindingResult bindingResult, Model model){
		if (bindingResult.hasErrors()) {
			System.out.println("BINDING RESULT ERROR");
			return "/adminMail/inbox";
			
		} else {
			model.addAttribute("reply", newReply);
			
			replyservice.addReply(newReply.getEmail(), newReply.getSubject(), newReply.getAdmin_reply(), newReply.getDate_time(), newReply.getEnquiry_id());
				
			return "redirect:/sentMail";
		}
	}
	
	public String checkNullString(String str){
		String endString = null;
		if(str == null || str.isEmpty()){
			System.out.println("yes it is empty");
			str = null;
			Optional<String> opt = Optional.ofNullable(str);
			endString = opt.orElse("None");
			System.out.println("endString : " + endString);
		}
		else{
			; //do nothing
		}
		return endString;
		
	}
}
