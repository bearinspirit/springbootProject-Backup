package com.project.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.project.model.Enquiry;
import com.project.model.Reply;
import com.project.repository.InboxRespository;
import com.project.repository.SentMailRepository;
import com.project.service.InboxService;
import com.project.service.SentMailService;

@Controller
public class SentMailController {
	@Autowired
	private SentMailRepository sentmailrepository;
	
	@Autowired
	private SentMailService sentmailservice;
	
	private ArrayList<Reply> replyList;
	

	@GetMapping(value="/sentMail")
	public String inbox(Model model) {
		List<Reply> listReply = sentmailservice.GetReplies();
		for (Reply reply: listReply) {
			replyList.add(reply);
		}
		
		model.addAttribute("replies", sentmailrepository.findAll());

		return "/adminMail/sentMail";
	}
}
