package com.project.service;

import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ReplyServiceImpl implements ReplyService{
	@Autowired
    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;
    
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }
	    
    public void addReply(String email, String subject, String admin_reply, Date date_time, Long enquiry_id) {
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcTemplate.update("INSERT INTO reply(email, subject, admin_reply, date_time, enquiry_id)VALUES(?, ?, ?, ?, ?)", email, subject, admin_reply, date_time, enquiry_id);
    
    }
	    
}
