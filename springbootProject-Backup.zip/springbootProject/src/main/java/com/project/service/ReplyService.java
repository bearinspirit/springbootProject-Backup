package com.project.service;

import java.util.Date;

public interface ReplyService {
	
	//add sent replies to DB
	 void addReply(String email, String subject, String admin_reply, Date date_time, Long enquiry_id);

}
