package com.project.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.project.model.Enquiry;

public interface InboxService {
	

	List GetEnquiries();
	
	
}
