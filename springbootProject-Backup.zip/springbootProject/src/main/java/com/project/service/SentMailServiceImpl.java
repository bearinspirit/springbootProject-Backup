package com.project.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import com.project.model.Reply;

@Service
public class SentMailServiceImpl implements SentMailService{
	@Autowired
    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;
    
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }
    

    
    public List GetReplies(){    	
    	
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM reply";
        List replyList = new ArrayList();
        jdbcTemplate.query(sql, new ResultSetExtractor() {
                public List extractData(ResultSet rs) throws SQLException {
                        
                        while (rs.next()) {
                        		Reply r = new Reply();
                        			r.setId(rs.getLong("id"));
                        			r.setDate_time((Date)rs.getDate("date_time"));
                        			r.setEmail(rs.getString("email"));
                        			r.setSubject(rs.getString("subject"));
                        			r.setAdmin_reply(rs.getString("admin_reply"));
                        }
                        return replyList;
                }
        });
        return replyList;

       
    }
}
