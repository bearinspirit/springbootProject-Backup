package com.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.model.Reply;

@Repository
public interface ReplyRepository extends CrudRepository<Reply,Long>{

	Reply findById(Long id);
	
}
